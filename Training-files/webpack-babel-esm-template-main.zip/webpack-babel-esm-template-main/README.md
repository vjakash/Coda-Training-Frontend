# webpack-babel-esm-template
Starter template for building web apps using webpack bundling
